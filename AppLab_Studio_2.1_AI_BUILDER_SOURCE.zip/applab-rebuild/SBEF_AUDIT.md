# AppLab v0.7 — SBEF audit (local)

SBEF = Scan, Bugs, Errors, Fixes. This is a **source-level and unit-test audit**, not a claim of full cross-platform verification.

## Scanned
- JavaScript syntax (`node --check` for all JS files).
- Node automated tests (`node --test`).
- Renderer DOM element IDs, duplicate IDs, and exposed preload API methods.
- Electron navigation, permissions, context isolation, renderer sandbox and privileged IPC sender checks.
- Documentation fetching URL policy and network availability handling.
- Project import, AI staging, rollback, static validation and export code.

## Changes in this version
- Added opt-in internet connectivity check and trusted HTTPS documentation retrieval.
- Added documentation context to AI CHAT, including source URL.
- Prevented arbitrary renderer window opens, blocked external navigation and denied unexpected permission requests.
- Validated privileged IPC sender against main window frame.
- Added bounded report serialization.
- Restricted Ollama installer final download host to expected hosts (additional official CDN hosts may need allowlisting after testing).
- Fixed canceled attachment dialog clearing an existing attachment.

## Still requires end-to-end verification
- Windows and macOS packaged installers, notarization/code signing, Ollama setup, model downloads, vision/audio/video tools, live network access, Electron UI and actual project builds.
- Static export does not compile Vite/React/Next source and cannot guarantee Netlify deployment or AdSense acceptance.
- Internet research currently reads selected approved documentation URLs only; not a general-purpose autonomous web browser.
- AI edits still need human approval and full browser regression tests.
- No GitHub push or deployment performed.
