'use strict';
const fs=require('node:fs'),path=require('node:path');
const {listFiles,within,validate,choosePublish}=(()=>{const e=require('./project-engine');return {...e,within:(r,p)=>path.resolve(r,p)}})();
function scan(root){const files=listFiles(root),issues=[],ids=new Map();const add=(severity,code,file,message)=>issues.push({severity,code,file,message});
 for(const rel of files){if(!/\.html?$/i.test(rel))continue;const html=fs.readFileSync(path.join(root,rel),'utf8');const found=new Set();for(const m of html.matchAll(/\bid\s*=\s*["']([^"']+)["']/gi)){if(found.has(m[1]))add('error','DUPLICATE_DOM_ID',rel,'Duplicate id '+m[1]);found.add(m[1])}ids.set(rel,found);
 for(const m of html.matchAll(/<script\b[^>]*?\bsrc\s*=\s*["']([^"']+)["']/gi)){if(/^https?:/i.test(m[1]))add('info','EXTERNAL_SCRIPT',rel,'External script requires live testing: '+m[1])}
 if(/<button\b/i.test(html))add('info','INTERACTION_TEST_REQUIRED',rel,'Buttons require browser interaction testing');
 }
 for(const rel of files.filter(x=>/\.[cm]?js$/i.test(x))){const js=fs.readFileSync(path.join(root,rel),'utf8');if(js.includes('document.getElementById'))for(const m of js.matchAll(/(?:document\.)?getElementById\s*\(\s*["']([^"']+)["']/g)){const matching=[...ids.values()].some(set=>set.has(m[1]));if(!matching)add('warning','MISSING_DOM_TARGET',rel,'Unresolved DOM id '+m[1]+' (could be dynamically created)')}}
 const publish=choosePublish(root);if(publish)for(const msg of validate(publish))add('error','BROKEN_STATIC_RESOURCE',path.relative(root,publish)||'.',msg);else add('warning','NO_STATIC_BUILD','.','Build required or unsupported SSR project');
 return {scannedAt:new Date().toISOString(),files:files.length,summary:{errors:issues.filter(x=>x.severity==='error').length,warnings:issues.filter(x=>x.severity==='warning').length},issues,limitations:['Static checks do not prove browser behavior','No execution of untrusted project code','External services and media pipelines require live testing']};}
module.exports={scan};
