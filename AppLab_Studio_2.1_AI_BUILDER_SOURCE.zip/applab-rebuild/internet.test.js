'use strict';const test=require('node:test'),assert=require('node:assert/strict');const {validateDocsUrl}=require('./internet');
test('allowlisted HTTPS documentation',()=>assert.equal(validateDocsUrl('https://docs.ollama.com/').hostname,'docs.ollama.com'));
for(const u of ['http://docs.ollama.com/','https://evil.com','https://docs.ollama.com.evil.com/','file:///etc/passwd','https://user:pass@docs.ollama.com/','https://docs.ollama.com:444/'])test('reject unsafe docs URL '+u,()=>assert.throws(()=>validateDocsUrl(u)));
