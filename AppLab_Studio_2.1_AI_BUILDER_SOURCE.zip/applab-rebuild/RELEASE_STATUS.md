# AppLab v1.0 Local Integration Status

New: local static preview HTTP server, smoke test, browser opening, start/stop controls.

This is a development source release, not a signed installer. AI chat and multimodal processing depend on installed Ollama and external tools. Browser regression testing, actual installer tests on Windows/macOS, and autonomous multi-step coding remain incomplete.

Security: project build executes untrusted code and must be user-approved. Preview server binds to loopback and rejects traversal and symlinks. No GitHub push or deployment.
