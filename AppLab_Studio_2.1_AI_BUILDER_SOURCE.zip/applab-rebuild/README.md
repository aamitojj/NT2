# AppLab AI Studio 0.6 — local development build

This is a **source-code development build**, not a verified Windows or macOS installer. It was built entirely locally; no GitHub push or deployment.

## Start

1. Install Node.js 22+ and Ollama (Windows or macOS).
2. Open a terminal in `applab-rebuild` and run `npm install`, then `npm start`.
3. In **System & Setup**, check Ollama. The **Download official Ollama installer** button downloads an official installer/archive after asking permission. On Windows, complete the installer. On macOS, extract the archive, move Ollama.app into Applications, and launch it. The installer is NOT silently installed.
4. In **AI Models**, download a coding model. For image/video, download **gemma3:4b** or **llava:7b**. Models may be large and require internet for initial download.
5. Use **AI CHAT** for natural language prompts, or **AI Repair & Export** to import a static site ZIP and propose changes.

## Media support

- Images: PNG, JPEG, WebP and GIF passed to a compatible Ollama vision model. Animated GIF is not processed frame by frame.
- Audio: WAV, MP3, M4A, FLAC, OGG. Requires installed `ffmpeg` and `whisper-cli` (whisper.cpp), plus `APPLAB_WHISPER_MODEL` environment variable pointing to a downloaded GGML model. Audio is transcribed locally; this dependency is **not auto-installed**.
- Video: MP4, MOV, MKV, WebM. Requires `ffmpeg` installed and on PATH. Samples three frames (0, 10 and 30 seconds), not full video understanding. Use a vision model.
- Documents: PDF (text-based), DOCX, XLSX, PPTX (slide text), CSV, code, text and ZIP manifest. Scanned PDF OCR is not implemented. Not every file can be interpreted perfectly.

## AI repair workflow

1. Import project ZIP. A temporary copy is extracted; original ZIP is unchanged.
2. Run **Safe AutoFix** for conservative HTML image hints and metadata warnings.
3. Enter instructions under **AI-assisted code changes**. A local model proposes JSON patches. Review each change and approve it before it modifies the temporary copy. No AI-proposed shell commands are executed.
4. Undo the last AI patch if needed. Validate local asset references.
5. Export a ZIP with `index.html` at the root for a **built static site**. Projects with `package.json` build scripts must first have `dist`, `build`, `out`, or `public` with a built `index.html`. This version does **not** run npm builds for you.

## Limitations and security

- This is not ChatGPT; output quality depends on the downloaded local model, which can make mistakes or fail to return valid edits.
- No autonomous iterative browser testing, build repair, code execution, or guaranteed deployment success yet.
- Static asset checks cannot guarantee that buttons, API calls, SEO, AdSense or runtime behavior work.
- Installer download does not yet verify an official published cryptographic checksum. Download and installation require user consent and OS security prompts.
- Audio/video features depend on external local command-line tools and are not yet a one-click setup.
- Model and document content is sent to the **local Ollama service** at 127.0.0.1; Ollama is separate software. Do not use with untrusted project ZIPs.
- Windows and macOS application packaging and end-to-end installed-app tests have not been completed.

## Tests

Run `npm test`. The automated tests cover safe paths, staging/rollback, static HTML checks, image classification, and existing AI-core tests. Electron integration, real Ollama downloads, audio/video transcription, and Windows/macOS installer flows remain unverified.

## Studio 2.1 prompt-to-app builder
Open **AI App Builder**, install/start Ollama and select a local model, describe a new static app and click **Generate new app with Ollama**. AppLab creates an isolated temporary workspace containing generated files, then opens Project Repair for inspection, testing, preview and export. Ollama generation is not guaranteed to produce a working application; review code and run checks. Existing workspace is replaced after confirmation; export important changes first.

**Local test:** `node --test`. **Desktop:** `npm install && npm start`. **Windows installer:** `npm run dist:win` on Windows with Node installed. This source ZIP is not an EXE.
