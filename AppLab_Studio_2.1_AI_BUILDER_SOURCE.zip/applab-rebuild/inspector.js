const fs=require('node:fs');
function inspectZip(file){
 const b=fs.readFileSync(file); const errors=[]; const warnings=[];
 if(b.length<22||b.readUInt32LE(0)!==0x04034b50)errors.push('Not a ZIP archive or invalid ZIP header');
 if(b.length>100*1024*1024)errors.push('ZIP exceeds 100 MB limit');
 const names=[];
 // Read central directory entries without extracting or executing untrusted content.
 for(let i=0;i+46<=b.length;i++){
  if(b.readUInt32LE(i)!==0x02014b50)continue;
  const nameLen=b.readUInt16LE(i+28),extra=b.readUInt16LE(i+30),comment=b.readUInt16LE(i+32);
  const end=i+46+nameLen+extra+comment;
  if(end>b.length){errors.push('Malformed ZIP directory');break;}
  const name=b.subarray(i+46,i+46+nameLen).toString('utf8');names.push(name);i=end-1;
 }
 if(!names.length)errors.push('No readable ZIP directory entries');
 const suspicious=names.filter(n=>n.startsWith('/')||n.includes('..')||/^[A-Za-z]:/.test(n));
 if(suspicious.length)errors.push('Unsafe ZIP entry paths detected');
 if(!names.some(n=>/(^|\/)index\.html$/i.test(n)))warnings.push('No index.html found (may require a build step)');
 if(names.some(n=>/(^|\/)(\.env|id_rsa|credentials\.json)$/i.test(n)))warnings.push('Potential secret file included');
 return {file,entries:names.length,errors,warnings,files:names.slice(0,200),status:errors.length?'FAIL':warnings.length?'REVIEW':'PASS',note:'Static ZIP inspection only. Does not build, preview, or execute uploaded applications.'};
}
module.exports={inspectZip};
